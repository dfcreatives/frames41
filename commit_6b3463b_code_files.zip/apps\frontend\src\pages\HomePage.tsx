import AnnouncementBar from '@/components/layout/AnnouncementBar'
import Navbar from '@/components/layout/Navbar'
import HeroSection from '../components/home/HeroSection'
import CategoryProductsSection from '../components/home/CategoryProductsSection'
import BudgetSection from '../components/home/BudgetSection'
import NewCollectionsSection from '../components/home/NewCollectionsSection'
import BestsellersSection from '../components/home/BestsellersSection'
import CustomerReviewsSection from '../components/home/CustomerReviewsSection'
import NewsletterStrip from '../components/home/NewsletterStrip'
import Footer from '@/components/layout/Footer'
import WelcomeOfferModal from '@/components/ui/WelcomeOfferModal'
import ProductSectionShimmer from '../components/ui/ProductSectionShimmer'
import { useHomePage } from '../hooks/useHomePage'
import {
  NAV_LINKS,
  HERO,
  FOOTER_COLUMNS,
  SOCIAL_LINKS,
} from '../constants/home'

export default function HomePage() {
  const { categorySections, budgetProducts, bestsellers, newCollections, heroBanners, allProducts, loading } = useHomePage()

  return (
    <>
      <AnnouncementBar />
      <Navbar links={NAV_LINKS} />
      <main id="main-content">
        <HeroSection
          data={HERO}
          banners={heroBanners}
          products={allProducts}
          onExploreCta={() => {
            const el = document.getElementById('collections')
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
          }}
        />

        {/* Mobile-only CTA between hero & collections */}
        <div className="sm:hidden px-4 mt-6 mb-6">
          <button
            type="button"
            onClick={() => {
              const el = document.getElementById('collections')
              if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
            }}
            className="w-full py-3 px-6 bg-[#800020] text-amber-200 font-extrabold uppercase tracking-wider text-xs rounded-xl shadow-md border border-amber-400/30 flex items-center justify-center gap-2 hover:bg-[#600018] transition-all"
          >
            Customise & Order
          </button>
        </div>

        {loading && !newCollections.length ? (
          <ProductSectionShimmer
            title="New Collections"
            eyebrow="Just In"
            count={4}
            layout="carousel"
          />
        ) : (
          <NewCollectionsSection products={newCollections} />
        )}
        {loading && !categorySections.length ? (
          <ProductSectionShimmer title="Categories" count={4} />
        ) : (
          <CategoryProductsSection sections={categorySections} />
        )}
        {loading && !budgetProducts.length ? (
          <ProductSectionShimmer title="Under Γé╣999" count={4} />
        ) : (
          <BudgetSection products={budgetProducts} priceLimit={999} />
        )}
        {loading && !bestsellers.length ? (
          <ProductSectionShimmer title="Bestsellers" count={3} layout="wide" />
        ) : (
          <BestsellersSection products={bestsellers} />
        )}
        <CustomerReviewsSection />
        <NewsletterStrip />
      </main>
      <Footer columns={FOOTER_COLUMNS} socialLinks={SOCIAL_LINKS} />
      <WelcomeOfferModal />
    </>
  )
}
